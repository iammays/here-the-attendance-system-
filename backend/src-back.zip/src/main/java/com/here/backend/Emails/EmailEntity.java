package com.here.backend.Emails;

public class EmailEntity {
    
}
