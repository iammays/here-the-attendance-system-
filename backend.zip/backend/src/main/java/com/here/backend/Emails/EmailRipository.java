package com.here.backend.Emails;

public class EmailRipository {
    
}
